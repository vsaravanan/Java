package com.github.elizabetht.service;

import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.elizabetht.mappers.StudentMapper;
import com.github.elizabetht.model.Student;

@Service("studentService")
//public class StudentServiceImpl implements StudentService {
public class StudentServiceImpl extends SqlSessionDaoSupport implements StudentService {
	@Autowired
	private StudentMapper studentMapper;
	
//	@Autowired
//	private SqlSession session;
	
	@Transactional
	public void insertStudent(Student student) {
		studentMapper.insertStudent(student);
	}

	public boolean getStudentByLogin(String userName, String password) {
		
		//Student student = studentMapper.getStudentByUserName(userName);
		//Student student = getSqlSession().selectOne("com.github.elizabetht.mappers.StudentMapper.getStudentByUserName2", userName);
		Student student = getSqlSession().selectOne("getStudentByUserName2", userName);
		//Student student = session.selectOne("com.github.elizabetht.mappers.StudentMapper2.getStudentByUserName2", userName);
		
		if(student != null && student.getPassword().equals(password)) {
			return true;
		}
		
		return false;
	}

	public boolean getStudentByUserName(String userName) {
		Student student = studentMapper.getStudentByUserName(userName);
		//Student student = getSqlSession().selectOne("com.github.elizabetht.mappers.StudentMapper.getStudentByUserName", userName);
		
		if(student != null) {
			return true;
		}
		
		return false;
	}

}
